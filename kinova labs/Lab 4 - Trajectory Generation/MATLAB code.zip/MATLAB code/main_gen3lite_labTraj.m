close all
clear all
gen3_lite=struct('IP_ADDRESS','192.168.1.10','ID','admin','PASSWORD','admin','SESSION_TIMEOUT',uint32(60000),'CONTROL_TIMEOUT',uint32(2000));
q0=[0;345;75;0;300;0];
v0=[0;0;0;0;0;0];
a0=[0;0;0;0;0;0];
qf=[40;300;100;70;350;-45];
vf=[0;0;0;0;0;0];
af=[0;0;0;0;0;0];
amax=[1;1;1;1;1;1];
t=0:0.001:20;
[qpoly,dqpoly,ddqpoly]=ang_traj_poly(q0,v0,a0,qf,vf,af,t);
[qtrap,dqtrap,ddqtrap]=ang_traj_trap(q0,v0,qf,vf,t,amax);
[qope,dqope,ddqope]=cart_traj(q0,qf,t);

for i=1:6
    figure(i)
    subplot(311)
    title('Position')
    plot(t,qpoly(i,:))
    hold on
    plot(t,qtrap(i,:))
    plot(t,qope(i,:))
    legend('Angular polynomial','Angular trapezoidal velocities','Cartesian')
    subplot(312)
    title('Velocity')
    plot(t,dqpoly(i,:))
    hold on
    plot(t,dqtrap(i,:))
    plot(t,dqope(i,:))
    legend('Angular polynomial','Angular trapezoidal','Cartesian')
    subplot(313)
    title('Acceleration')
    plot(t,ddqpoly(i,:))
    hold on
    plot(t,ddqtrap(i,:))
    plot(t,ddqope(i,:))
    legend('Angular polynomial','Angular trapezoidal','Cartesian')

end
disp('Return to home')
[~]=cindir_gen3_lite(gen3_lite,[0,345,75,0,300,0]);
disp('Angular polynomial')
[~, gen3_lite_handle, ~] = kortexApiMexInterface('CreateRobotApisWrapper', gen3_lite.IP_ADDRESS, gen3_lite.ID, gen3_lite.PASSWORD, gen3_lite.SESSION_TIMEOUT, gen3_lite.CONTROL_TIMEOUT);
[~] = kortexApiMexInterface('PlayPreComputedTrajectory', gen3_lite_handle,int32(1), qpoly, dqpoly, ddqpoly,[t;t;t;t;t;t]);
pause(30)
[~] = kortexApiMexInterface('DestroyRobotApisWrapper', gen3_lite_handle);
disp('Return to home')
[~]=fk_gen3_lite(gen3_lite,[0,345,75,0,300,0]);
disp('Angular trapezoidal velocities')
[~, gen3_lite_handle, ~] = kortexApiMexInterface('CreateRobotApisWrapper', gen3_lite.IP_ADDRESS, gen3_lite.ID, gen3_lite.PASSWORD, gen3_lite.SESSION_TIMEOUT, gen3_lite.CONTROL_TIMEOUT);
[~] = kortexApiMexInterface('PlayPreComputedTrajectory', gen3_lite_handle,int32(1), qtrap, dqtrap, ddqtrap,[t;t;t;t;t;t]);
pause(30)
[~] = kortexApiMexInterface('DestroyRobotApisWrapper', gen3_lite_handle);
disp('Return to home')
[~]=fk_gen3_lite(gen3_lite,[0,345,75,0,300,0]);
disp('Cartesian')
[~, gen3_lite_handle, ~] = kortexApiMexInterface('CreateRobotApisWrapper', gen3_lite.IP_ADDRESS, gen3_lite.ID, gen3_lite.PASSWORD, gen3_lite.SESSION_TIMEOUT, gen3_lite.CONTROL_TIMEOUT);
[~] = kortexApiMexInterface('PlayPreComputedTrajectory', gen3_lite_handle,int32(1), qope, dqope, ddqope,[t;t;t;t;t;t]);
pause(30)
[~] = kortexApiMexInterface('DestroyRobotApisWrapper', gen3_lite_handle);