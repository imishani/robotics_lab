function [q,dq,ddq] = cart_traj(q0,qf,t)
T0=fk_gen3_lite_rt(q0');
Tf=fk_gen3_lite_rt(qf');
Td=zeros(4,4,size(t,2));
Vd=zeros(6,size(t,2));
Tdd=zeros(4,4,size(t,2));
qd=zeros(6,size(t,2));
q=zeros(6,size(t,2));
dq=zeros(6,size(t,2));
ddq=zeros(6,size(t,2));
qd(:,1)=q0;
s=t/t(1,end);
error=Tf/T0;
R=error(1:3,1:3);
if trace(R)==3
    theta=norm(error(1:3,4));
    omega=[0;0;0];
    v=(error(1:3,4))/norm(error(1:3,4));
else
    if trace(R)==-1
        theta=pi/2;
        omega1=sqrt((R(1,1)+1)/2);
        omega2=sign(R(1,2))*sqrt((R(2,2)+1)/2);
        omega3=sign(R(1,3))*sqrt((R(3,3)+1)/2);
        omega=[omega1;omega2;omega3];
    else
        theta=acos((trace(R)-1)/2);
        omega=1/(2*sin(theta))*[R(3,2)-R(2,3);R(1,3)-R(3,1);R(2,1)-R(1,2)];
    end
    A=(eye(3)-R)*skewm(omega)+theta*(omega*omega');
    v=A\(error(1:3,4));
end
xi(1:3,1)=theta*omega;
xi(4:6,1)=theta*v;
for i=1:size(t,2)
    xi_land=[skewm(xi(1:3,1)) xi(4:6,1);zeros(1,4)];
    Td(:,:,i)=expm(s(1,i)*xi_land)*T0;
    if i>1
        Tdd(:,:,i)=(Td(:,:,i)-Td(:,:,i-1))/0.001;
        Vd_land=Tdd(:,:,i)/Td(:,:,i);
        Vd(:,i)=[(-Vd_land(2,3)+Vd_land(3,2))/2;(Vd_land(1,3)-Vd_land(3,1))/2;(-Vd_land(1,2)+Vd_land(2,1))/2;Vd_land(1,4);Vd_land(2,4);Vd_land(3,4)];
        js=jacob_gen3_lite_s(qd(:,i-1));
        qd(:,i)=qd(:,i-1)+js'/(js*js')*Vd(:,i)*0.001;%Differential ik unused here
    end 
    q(:,i)=ik_gen3_lite_iterative(squeeze(Td(:,:,i)),0,'ru',1);
end
dq(:,2:end)=(q(:,2:end)-q(:,1:end-1))/0.001;
ddq(:,2:end)=(dq(:,2:end)-dq(:,1:end-1))/0.001;
for i=1:6 %Saturations
    for j=1:size(t,2)
        if dq(i,j)>50
            dq(i,j)=50;
        end
        if ddq(i,j)>1
            ddq(i,j)=1;
        end
        if dq(i,j)<-50
            dq(i,j)=-50;
        end
        if ddq(i,j)<-1
            ddq(i,j)=-1;
        end
    end
end
end

