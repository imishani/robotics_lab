function [q,dq,ddq] = ang_traj_poly(q0,v0,a0,qf,vf,af,t)
td=t(end);
N=size(t,2);
nb_joint=size(q0,1);
q=zeros(nb_joint,N);
dq=zeros(nb_joint,N);
ddq=zeros(nb_joint,N);
for i=1:nb_joint
    A=[1 0 0 0 0 0
        0 1 0 0 0 0
        0 0 2 0 0 0
        1 td td^2 td^3 td^4 td^5
        0 1 2*td 3*td^2 4*td^3 5*td^4
        0 0 2 6*td 12*td^2 20*td^3];
    B=[q0(i,1);v0(i,1);a0(i,1);qf(i,1);vf(i,1);af(i,1)];
    X=A\B;
    q(i,:)=X(1)+X(2)*t+X(3)*t.^2+X(4)*t.^3+X(5)*t.^4+X(6)*t.^5;
    dq(i,:)=X(2)+2*X(3)*t+3*X(4)*t.^2+4*X(5)*t.^3+5*X(6)*t.^4;
    ddq(i,:)=2*X(3)+6*X(4)*t+12*X(5)*t.^2+20*X(6)*t.^3;
end

