function [q,dq,ddq] = ang_traj_trap(q0,v0,qf,vf,t,amax)
td=t(end);
N=size(t,2);
nb_joint=size(q0,1);
q=zeros(nb_joint,N);
dq=zeros(nb_joint,N);
ddq=zeros(nb_joint,N);
vmax=zeros(6,1);
for i=1:nb_joint
    if qf(i,1)>q0(i,1)
        vmax(i,1)=(v0(i,1)+vf(i,1)+td*amax(i,1))/2-0.5*sqrt((v0(i,1)+vf(i,1)+td*amax(i,1))^2-2*(v0(i,1)^2+vf(i,1)^2)-4*amax(i,1)*(qf(i,1)-q0(i,1)));
        t1=(vmax(i,1)-v0(i,1))/amax(i,1);
        i1=round(t1*1000)+1;
        q(i,1:i1)=q0(i,1)+v0(i,1)*t(1:i1)+amax(i,1)*t(1:i1).^2/2;
        dq(i,1:i1)=v0(i,1)+amax(i,1)*t(1:i1);
        ddq(i,1:i1)=amax(i,1);
        t2=td-(vmax(i,1)-vf(i,1))/amax(i,1);
        i2=round(t2*1000)+1;
        q(i,i1:i2)=q0(i,1)+(vmax(i,1)^2-v0(i,1)^2)/(2*amax(i,1))+vmax(i,1)*(t(i1:i2)-t1);
        dq(i,i1:i2)=vmax(i,1);
        ddq(i,i1:i2)=0;
        q(i,i2:end)=qf(i,1)+vmax(i,1)*(t(i2:end)-td)-amax(i,1)/2*(td-t(i2:end)).*(td-t(i2:end)-2*(vmax(i,1)-vf(i,1))/amax(i,1));
        dq(i,i2:end)=vmax(i,1)-amax(i,1)*(t(i2:end)-t2);
        ddq(i,i2:end)=-amax(i,1);
    else
        vmax(i,1)=(v0(i,1)+vf(i,1)-td*amax(i,1))/2+0.5*sqrt((v0(i,1)+vf(i,1)-td*amax(i,1))^2-2*(v0(i,1)^2+vf(i,1)^2)-4*amax(i,1)*(q0(i,1)-qf(i,1)));
        t1=(-vmax(i,1)+v0(i,1))/amax(i,1);
        i1=round(t1*1000)+1;
        q(i,1:i1)=q0(i,1)+v0(i,1)*t(1:i1)-amax(i,1)*t(1:i1).^2/2;
        dq(i,1:i1)=v0(i,1)-amax(i,1)*t(1:i1);
        ddq(i,1:i1)=-amax(i,1);
        t2=td-(-vmax(i,1)+vf(i,1))/amax(i,1);
        i2=round(t2*1000)+1;
        q(i,i1:i2)=q0(i,1)+(-vmax(i,1)^2+v0(i,1)^2)/(2*amax(i,1))+vmax(i,1)*(t(i1:i2)-t1);
        dq(i,i1:i2)=vmax(i,1);
        ddq(i,i1:i2)=0;
        q(i,i2:end)=qf(i,1)+vmax(i,1)*(t(i2:end)-td)+amax(i,1)/2*(td-t(i2:end)).*(td-t(i2:end)+2*(vmax(i,1)-vf(i,1))/amax(i,1));
        dq(i,i2:end)=+vmax(i,1)+amax(i,1)*(t(i2:end)-t2);
        ddq(i,i2:end)=+amax(i,1);
    end
end

