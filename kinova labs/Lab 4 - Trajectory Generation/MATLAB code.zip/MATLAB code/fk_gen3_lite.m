function [tool_pose] = fk_gen3_lite(gen3_lite,q)
N=size(q);
tool_pose=zeros(4,4,N(1));
gen3_lite=struct('IP_ADDRESS','192.168.1.10','ID','admin','PASSWORD','admin','SESSION_TIMEOUT',uint32(60000),'CONTROL_TIMEOUT',uint32(2000));
[~, gen3_lite_handle, ~] = kortexApiMexInterface('CreateRobotApisWrapper', gen3_lite.IP_ADDRESS, gen3_lite.ID, gen3_lite.PASSWORD, gen3_lite.SESSION_TIMEOUT, gen3_lite.CONTROL_TIMEOUT);
for i=1:N(1)
    [~] = kortexApiMexInterface('ReachJointAngles', gen3_lite_handle,int32(0), 0, 0, [q(1),q(2),q(3),q(4),q(5),q(6)]); 
    pause(10) 
    [~,BaseFeedback,~,~] = kortexApiMexInterface('RefreshFeedback',gen3_lite_handle);
    tool_pose_cart=BaseFeedback.tool_pose;
    tool_pose(:,:,i)=cart2pose(tool_pose_cart);
end
[~] = kortexApiMexInterface('DestroyRobotApisWrapper', gen3_lite_handle);
